package com.app.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.Owner;

@Repository
public interface OwnerRepository extends JpaRepository<Owner, Long> {
    // add custom query methods if needed
	Optional<Owner> findByEmail(String email);
}
