package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Booking;
import com.app.entity.Customer;
import com.app.exception.ResourceNotFoundException;
import com.app.repository.BookingRepository;
import com.app.repository.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
    private CustomerRepository customerRepository;

	@Autowired
	private BookingRepository bookingRepository;

	
    @Override
    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public Customer updateCustomer(Long id, Customer customer) {
        Customer existingCustomer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid customer ID"));
        customer.setId(id);
        return customerRepository.save(customer);
    }

    @Override
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }

    @Override
    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid customer ID"));
    }

    @Override
    public List<Customer> getAllCustomers() {
    	
    	List<Customer> cms = customerRepository.findAll();
    	
    	
        return cms;
    }

	@Override
	public List<Booking> getCustomerBookings(Long id) {
		Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid customer ID"));
		return bookingRepository.findAllByCustomer(customer);
	}

	@Override
	public Customer getCustomerByEmail(String email) {
		
		return customerRepository.findByEmail(email).orElse(null);
	}

}