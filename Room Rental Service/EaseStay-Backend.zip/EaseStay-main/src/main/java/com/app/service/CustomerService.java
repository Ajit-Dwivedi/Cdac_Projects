package com.app.service;

import java.util.List;

import com.app.entity.Booking;
import com.app.entity.Customer;


public interface CustomerService {

    Customer createCustomer(Customer customer);

    Customer updateCustomer(Long id, Customer customer);

    void deleteCustomer(Long id);

    Customer getCustomerById(Long id);
    
    Customer getCustomerByEmail(String email);

    List<Customer> getAllCustomers();

	List<Booking> getCustomerBookings(Long id);

}

