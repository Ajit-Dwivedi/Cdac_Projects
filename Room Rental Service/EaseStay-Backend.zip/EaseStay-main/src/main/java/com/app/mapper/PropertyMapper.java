package com.app.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.dto.PropertyDTO;
import com.app.entity.Property;
import com.app.repository.BookingRepository;
import com.app.repository.ImageRepository;
import com.app.repository.OwnerRepository;

@Component
public class PropertyMapper {

	@Autowired
	private OwnerRepository ownerRepository;
	
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private ImageRepository imageRepository;
	
    public PropertyDTO toDTO(Property property) {
        PropertyDTO dto = new PropertyDTO();
        dto.setId(property.getId());
        dto.setName(property.getName());
        dto.setType(property.getType());
        dto.setFeatures(property.getFeatures());
        dto.setDescription(property.getDescription());
        dto.setCapacity(property.getCapacity());
        dto.setAddress(property.getAddress());
        dto.setPricePerNight(property.getPricePerNight());
        if (property.getOwner() != null) {
            dto.setOwnerId(property.getOwner().getId());
        }
//        if (property.getBookings() != null) {
//            dto.setBookingIds(property.getBookings().stream()
//                    .map(booking -> booking.getId())
//                    .collect(Collectors.toList()));
//        }
        if (property.getImages() != null) {
            dto.setImageUrls(property.getImages().stream()
                    .map(image -> image.getUrl())
                    .collect(Collectors.toList()));
        }
        return dto;
    }

    public List<PropertyDTO> toDTOList(List<Property> properties) {
        return properties.stream()
                .map(property -> toDTO(property))
                .collect(Collectors.toList());
    }

    public Property toEntity(PropertyDTO dto) {
        Property property = new Property();
        property.setId(dto.getId());
        property.setName(dto.getName());
        property.setType(dto.getType());
        property.setFeatures(dto.getFeatures());
        property.setDescription(dto.getDescription());
        property.setCapacity(dto.getCapacity());
        property.setAddress(dto.getAddress());
        property.setPricePerNight(dto.getPricePerNight());
        property.setOwner(ownerRepository.getReferenceById(dto.getOwnerId()));
        //property.setBookings(bookingRepository.findAllByProperty(property));
        property.setImages(imageRepository.findAllByProperty(property));
        return property;
    }

}
