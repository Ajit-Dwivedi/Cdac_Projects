package com.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthenticationResponse {
	private String jwt;
	private Long id;
	private String username;
	private String name;
	private String phoneNumber;
	private String role;
	public AuthenticationResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AuthenticationResponse(String jwt, Long id, String username, String name, String phoneNumber, String role) {
		super();
		this.jwt = jwt;
		this.id = id;
		this.username = username;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.role = role;
	}
	public String getJwt() {
		return jwt;
	}
	public void setJwt(String jwt) {
		this.jwt = jwt;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "AuthenticationResponse [jwt=" + jwt + ", id=" + id + ", username=" + username + ", name=" + name
				+ ", phoneNumber=" + phoneNumber + ", role=" + role + "]";
	}
	
	
}
