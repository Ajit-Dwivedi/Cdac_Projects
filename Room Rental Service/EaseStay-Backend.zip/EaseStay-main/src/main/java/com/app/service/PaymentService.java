package com.app.service;

import com.app.entity.Payment;

public interface PaymentService {
	
	public Payment addPayment(Payment payment);
	
	public Payment getPaymentById(Long id);
	
	public void deletePaymentById(Long id);
	
}
