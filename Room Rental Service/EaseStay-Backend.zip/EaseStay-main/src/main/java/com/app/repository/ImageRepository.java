package com.app.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.entity.Image;
import com.app.entity.Property;

@Repository
public interface ImageRepository extends JpaRepository<Image, Long> {

	List<Image> findAllByProperty(Property property);
    // add custom query methods if needed
}
