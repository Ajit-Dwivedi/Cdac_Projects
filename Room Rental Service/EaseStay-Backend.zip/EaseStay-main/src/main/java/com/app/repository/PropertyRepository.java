package com.app.repository;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.app.entity.Property;
import com.app.entity.Type;

@Repository
public interface PropertyRepository extends JpaRepository<Property, Long> {
    
	List<Property> findByOwnerId(Long ownerId);
	
	@Query(
			value = " select * from properties where id Not in"
					+ " (select p.id from bookings b inner join properties p"
					+ "					on b.property_id = p.id" // p.id
					+ "					WHERE b.start_date >= :startDate  AND b.start_date <= :endDate" //date('2023-01-10') date('2023-01-14')
					+ "                    or b.end_date >= :startDate  AND b.end_date <= :endDate) "
					+ "                   and lower(city) = :destination and capacity >= :maxPeople",	// pune , 2	
			nativeQuery = true)
	List<Property> getAllPropertiesByCriteria(@PathVariable("startDate") LocalDate startDate,
			                                  @PathVariable("endDate") LocalDate endDate,
			                                  @PathVariable("destination") String destination,
			                                  @PathVariable("maxPeople") Long maxPeople );
	
	Long countByType(Type type);
	
}
