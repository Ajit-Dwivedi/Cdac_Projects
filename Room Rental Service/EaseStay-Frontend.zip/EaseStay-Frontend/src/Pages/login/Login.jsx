
import Navbar from "../../Component/navbar/Navbar"
import LoginForm from "./LoginForm"

const Login = () => {

return (
    <div>
<Navbar></Navbar>
<LoginForm></LoginForm>
    </div>
)

}

export default Login;