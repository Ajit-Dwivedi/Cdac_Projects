package com.app.configuration;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.app.filter.JwtTokenFilter;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
    private JwtTokenFilter jwtTokenFilter;
    
    
    @Autowired
	private UserDetailsService userDetailsService;

    @Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		System.out.println(1);
		// since there is no out-of-box imple for JPA based auth , u have to create a
		// custom class implementation of UserDetailsService n pass it here.
		// javadocs : Add authentication based upon the custom UserDetailsService that
		// is passed in.
		// It then returns a DaoAuthenticationConfigurer to allow customization of the
		// authentication.
		auth.userDetailsService(userDetailsService);
	}
    

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // Enable CORS and disable CSRF
//        http = http.cors().and().csrf().disable();
    	
    	http = http.cors().and().csrf().disable().httpBasic().disable();
    			;
    	
    	

        // Set session management to stateless
        http = http
            .sessionManagement()
            .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and();

        // Set unauthorized requests exception handler
        http = http
            .exceptionHandling()
            .authenticationEntryPoint(
                (request, response, ex) -> {
                    response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        ex.getMessage()
                    );
                }
            )
            .and();

        // Set permissions on endpoints
        http.authorizeRequests()
            // Our public endpoints
            .antMatchers("/api/properties/**").permitAll()
            .antMatchers("/api/signin").permitAll()
            .antMatchers("/api/customers/**").hasAuthority("Customer")
//            .antMatchers(HttpMethod.GET, "/api/properties/**").permitAll()
//            .antMatchers(HttpMethod.POST, "/api/bookings").permitAll()
//            .antMatchers(HttpMethod.GET, "/api/book/**").permitAll()
//            .antMatchers(HttpMethod.POST, "/api/book/search").permitAll()
            // Our private endpoints
            .anyRequest().authenticated();

        // Add JWT token filter
        http.addFilterBefore(
            jwtTokenFilter,
            UsernamePasswordAuthenticationFilter.class
        );
    }

    // Used by Spring Security if CORS is enabled.
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source =
            new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOrigin("http://localhost:3000");
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

    
    @Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {

		return super.authenticationManagerBean();
	}
    
    @Bean // To configure a spring bean (return type of this method will be a spring bean
	// after configuring password encoder bean : u will have to supply encoded
	// password in auth config
	// o.w : Encoded password does not look like BCrypt : warning (& authentication
	// does not work
	// : equivalent to <bean id ...> tag in xml)
	public PasswordEncoder encoder() {
		System.out.println(2);
		return new BCryptPasswordEncoder();
	}

}