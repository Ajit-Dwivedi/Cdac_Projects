package com.app.service;


import java.util.List;

import com.app.entity.Image;

public interface ImageService {
    public List<Image> getAllImages();
    public Image getImageById(Long id);
    public Image addImage(Image image);
    public Image updateImage(Image image);
    public void deleteImageById(Long id);
}
