package com.app.service;

import java.util.List;

import com.app.entity.Review;

public interface ReviewService {
    Review saveReview(Review review);
    Review updateReview(Review review);
    void deleteReviewById(Long id);
    Review findReviewById(Long id);
    List<Review> findAllReviews();
    List<Review> findReviewsByProperyId(Long id);
}
