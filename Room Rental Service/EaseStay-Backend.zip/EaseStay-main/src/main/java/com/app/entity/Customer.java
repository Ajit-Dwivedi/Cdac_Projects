package com.app.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Entity
@Data
@DiscriminatorValue("customer")
public class Customer extends User {
	 	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	    @JsonIgnoreProperties("customer")
	    private List<Booking> bookings;
}

