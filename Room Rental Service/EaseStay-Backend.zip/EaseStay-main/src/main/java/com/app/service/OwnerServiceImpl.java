package com.app.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.Owner;
import com.app.entity.Property;
import com.app.exception.ResourceNotFoundException;
import com.app.repository.OwnerRepository;

@Service
@Transactional
public class OwnerServiceImpl implements OwnerService {
	@Autowired
    private OwnerRepository ownerRepository;

    
    @Override
    public Owner updateOwner(Long ownerId, Owner owner) {
        Owner existingOwner = ownerRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid owner id"));
        owner.setId(ownerId);
        return ownerRepository.save(owner);
    }

    @Override
    public Owner getOwnerById(Long ownerId) {
        return ownerRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid owner id"));
    }

    @Override
    public void deleteOwnerById(Long ownerId) {
        Owner owner = ownerRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid owner id"));
        ownerRepository.delete(owner);
    }

	@Override
	public Owner createOwner(Owner owner) {
		return ownerRepository.save(owner);
	}

	@Override
	public List<Property> getProperties(Long ownerId) {
		Owner owner = getOwnerById(ownerId);
		return owner.getProperties();
	}

	@Override
	public Owner getOwnerByEmail(String email) {
		
		return ownerRepository.findByEmail(email).orElse(null);
	}
}

