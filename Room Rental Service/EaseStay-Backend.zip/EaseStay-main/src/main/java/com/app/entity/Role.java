package com.app.entity;

public enum Role {
	ROLE_CUSTOMER, ROLE_OWNER
}
