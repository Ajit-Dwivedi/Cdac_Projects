package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dto.Criteria;
import com.app.dto.HotelTypeCountDTO;
import com.app.entity.Property;
import com.app.entity.Type;
import com.app.exception.ResourceNotFoundException;
import com.app.repository.PropertyRepository;

@Service
@Transactional
public class PropertyServiceImpl implements PropertyService {

    @Autowired
    private PropertyRepository propertyRepository;

    @Override
    public Property getPropertyById(Long id) {
        return propertyRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Invalid Property ID"));
    }

    @Override
    public List<Property> getAllProperties() {
        return propertyRepository.findAll();
    }

    @Override
    public List<Property> getPropertiesByOwnerId(Long ownerId) {
        return propertyRepository.findByOwnerId(ownerId);
    }

    @Override
    public Property saveProperty(Property property) {
        return propertyRepository.save(property);
    }

    @Override
    public void deleteProperty(Long id) {
        propertyRepository.deleteById(id);
    }

	@Override
	public List<Property> getAllPropertiesByCriteria(Criteria criteria) {
	
		return propertyRepository.getAllPropertiesByCriteria(criteria.getStartDate(),
				                                             criteria.getEndDate(),
				                                             criteria.getDestination(),
				                                             criteria.getMaxPeople());
	}

	@Override
	public Property updateProperty(Long id, Property newProperty) {
		Property property = propertyRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Invalid Property ID"));
		newProperty.setId(id);
		return propertyRepository.save(newProperty);
	}

	@Override
	public List<HotelTypeCountDTO> getCountByType() {
		List<HotelTypeCountDTO> countByType = new ArrayList<>();
		for(Type type : Type.values()) {
			countByType.add(new HotelTypeCountDTO(type,  propertyRepository.countByType(type)));
		}
		return countByType;
	}
	


}
