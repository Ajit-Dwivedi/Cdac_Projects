package com.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReviewDTO {
    private Long id;
    
    private String comment;
    
    private Integer rating;
    
    private Long customerId;
    
    private Long propertyId;
    
    private Long bookingId;

	public ReviewDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReviewDTO(Long id, String comment, Integer rating, Long customerId, Long propertyId, Long bookingId) {
		super();
		this.id = id;
		this.comment = comment;
		this.rating = rating;
		this.customerId = customerId;
		this.propertyId = propertyId;
		this.bookingId = bookingId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	@Override
	public String toString() {
		return "ReviewDTO [id=" + id + ", comment=" + comment + ", rating=" + rating + ", customerId=" + customerId
				+ ", propertyId=" + propertyId + ", bookingId=" + bookingId + "]";
	}
    
    
}
