const IMAGES = {
  Error401: "./assets/images/401.png",
  Error404: "./assets/images/404.png",
  Error500: "./assets/images/500.png",
  locationIcon: "./assets/images/location.png",
  EVENT_1: "./assets/images/event1.jpeg",
  Dish: "./assets/images/dish.png",
  Dish2: "./assets/images/Dish2.png",
  Contact: "./assets/images/ContactImage.png",
};

export default IMAGES;
