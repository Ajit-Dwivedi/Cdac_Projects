package com.app.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Booking;
import com.app.exception.ResourceNotFoundException;
import com.app.repository.BookingRepository;

@Service
@Transactional
public class BookingServiceImpl implements BookingService{

	 @Autowired
	 private BookingRepository bookingRepository;
	 
	@Override
	public Booking getBookingById(Long id) {
		Optional<Booking> booking = bookingRepository.findById(id);
		if(booking.isPresent()) {
			return booking.get();
		}
		throw new ResourceNotFoundException("Booking not found!");
	}

	@Override
	public List<Booking> getBookings() {
		return bookingRepository.findAll();
	}

	@Override
	public Booking createBooking(Booking booking) {
		Booking newBooking = bookingRepository.save(booking);
		return newBooking;
	}

	@Override
	public Booking updateBooking(Long id, Booking newBooking) {
		 Optional<Booking> bookingOptional = bookingRepository.findById(id);
	        if (!bookingOptional.isPresent()) {
	            throw new ResourceNotFoundException("Booking not found!");
	        }
	        newBooking.setId(id);
	        Booking updatedBooking = bookingRepository.save(newBooking);
	        return updatedBooking;
	}

	@Override
	public void deleteBookingById(Long id) {
//		Optional<Booking> bookingOptional = bookingRepository.findById(id);
//        if (!bookingOptional.isPresent()) {
//            throw new ResourceNotFoundException("Booking not found!");
//        }
        bookingRepository.deleteById(id);
	}

}
