package com.app.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class UserDTO {
    private Long id;
    
    private String name;
    
    private LocalDate dateOfBirth;
    
    private String email;
    
    private String phoneNumber;
}
