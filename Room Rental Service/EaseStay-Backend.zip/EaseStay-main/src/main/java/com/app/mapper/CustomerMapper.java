package com.app.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.dto.CustomerDTO;
import com.app.entity.Customer;
import com.app.repository.BookingRepository;

@Component
public class CustomerMapper {

	@Autowired
	private BookingRepository bookingRepository;
    public CustomerDTO toDto(Customer customer) {
        CustomerDTO dto = new CustomerDTO();
        dto.setId(customer.getId());
        dto.setName(customer.getName());
        dto.setDateOfBirth(customer.getDateOfBirth());
        dto.setEmail(customer.getEmail());
        dto.setPhoneNumber(customer.getPhoneNumber());
        //dto.setBookingIds(customer.getBookings().stream().map(booking -> booking.getId()).collect(Collectors.toList()));
        return dto;
    }

    public Customer toEntity(CustomerDTO dto) {
        Customer customer = new Customer();
        customer.setId(dto.getId());
        customer.setName(dto.getName());
        customer.setDateOfBirth(dto.getDateOfBirth());
        customer.setEmail(dto.getEmail());
        customer.setPhoneNumber(dto.getPhoneNumber());
      //  customer.setBookings(dto.getBookingIds().stream().map(id -> bookingRepository.getReferenceById(id)).collect(Collectors.toList()));
        return customer;
    }

    public List<CustomerDTO> toDtoList(List<Customer> customers) {
        return customers.stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<Customer> toEntityList(List<CustomerDTO> dtos) {
        return dtos.stream().map(this::toEntity).collect(Collectors.toList());
    }
}
