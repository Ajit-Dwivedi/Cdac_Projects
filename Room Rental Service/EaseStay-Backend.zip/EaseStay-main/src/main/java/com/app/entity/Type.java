package com.app.entity;

public enum Type {
	Villa,
	Bunglow,
	Resort,
	Apartment
}
