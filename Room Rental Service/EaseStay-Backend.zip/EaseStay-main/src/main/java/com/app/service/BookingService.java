package com.app.service;

import java.util.List;

import com.app.entity.Booking;

public interface BookingService {
		Booking getBookingById(Long id);
		
		List<Booking> getBookings();
		
		Booking createBooking(Booking booking);
		
		Booking updateBooking(Long id,Booking newBooking);
		
		void deleteBookingById(Long id);
		
}
