package com.app.service;


import java.util.List;

import com.app.entity.Owner;
import com.app.entity.Property;

public interface OwnerService {
    Owner createOwner(Owner owner);
    Owner updateOwner(Long ownerId, Owner owner);
    Owner getOwnerById(Long ownerId);
    void deleteOwnerById(Long ownerId);
    List<Property> getProperties(Long ownerId);
    Owner getOwnerByEmail(String email);
}
