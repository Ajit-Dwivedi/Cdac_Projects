


const Test = (props) => {

    const {test} = props
        console.log(test)
    return (
        <div>
      
        </div>
    )
}

export default Test