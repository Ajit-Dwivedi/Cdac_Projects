package com.app.entity;

import javax.persistence.*;

import lombok.*;

@Data
@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "booking_id", nullable = false)
    private Booking booking;
    
    @Column(nullable = false)
    private double amount;
    
    @Column(nullable = false)
    private String paymentMethod;
}
