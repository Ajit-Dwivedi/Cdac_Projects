package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.BookingDTO;
import com.app.dto.CustomerDTO;
import com.app.entity.Booking;
import com.app.entity.Customer;
import com.app.mapper.BookingMapper;
import com.app.mapper.CustomerMapper;
import com.app.service.CustomerService;

@RestController
@RequestMapping("/api/customers")
//@CrossOrigin(origins = "http://localhost:3000")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private CustomerMapper customerMapper;
    
    @Autowired
    private BookingMapper bookingMapper;

    @GetMapping("")
    public List<CustomerDTO> getAllCustomers() {
        return customerMapper.toDtoList(customerService.getAllCustomers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
        Customer customer = customerService.getCustomerById(id);
        return new ResponseEntity<>(customerMapper.toDto(customer), HttpStatus.CREATED);
        
    }

    @PostMapping("")
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
    	Customer customer = customerMapper.toEntity(customerDTO);
        Customer createdCustomer = customerService.createCustomer(customer);
        return new ResponseEntity<>(customerMapper.toDto(createdCustomer), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable Long id, @RequestBody CustomerDTO customerDTO) {
    	Customer customer = customerMapper.toEntity(customerDTO);
    	
    	Customer updatedCustomer = customerService.updateCustomer(id,customer);
        
        return new ResponseEntity<>(customerMapper.toDto(updatedCustomer), HttpStatus.OK);
        
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/bookings")
    public ResponseEntity<List<BookingDTO>> getCustomerBookings(@PathVariable Long id) {
        List<Booking> bookings = customerService.getCustomerBookings(id);
        return ResponseEntity.ok(bookingMapper.toDTOList(bookings));
        
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> loginCustomer(){
    	
    	return null;
    }
}
