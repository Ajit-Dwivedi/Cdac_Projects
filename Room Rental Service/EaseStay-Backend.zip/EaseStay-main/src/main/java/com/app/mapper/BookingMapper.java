package com.app.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.dto.BookingDTO;
import com.app.entity.Booking;
import com.app.repository.CustomerRepository;
import com.app.repository.OwnerRepository;
import com.app.repository.PaymentRepository;
import com.app.repository.PropertyRepository;
import com.app.repository.ReviewRepository;

@Component
public class BookingMapper {

	@Autowired
	private OwnerRepository ownerRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private PropertyRepository propertyRepository;
	
	@Autowired
	private PaymentRepository paymentRepository ;
	
	@Autowired 
	private ReviewRepository reviewRepository;
	
    public BookingDTO toDTO(Booking booking) {
        BookingDTO dto = new BookingDTO();
        dto.setId(booking.getId());
        dto.setStartDate(booking.getStartDate());
        dto.setEndDate(booking.getEndDate());
        dto.setCustomerId(booking.getCustomer().getId());
        dto.setPropertyId(booking.getProperty().getId());
        dto.setTotalPrice(booking.getTotalPrice());
        dto.setOwnerId(booking.getOwner().getId());
        dto.setNumGuests(booking.getNumGuests());
        dto.setPaymentId(booking.getPayment() != null ? booking.getPayment().getId() : null);
//        dto.setReviewIds(booking.getReviews().stream().map(r -> r.getId()).collect(Collectors.toList()));
        return dto;
    }

    public List<BookingDTO> toDTOList(List<Booking> bookings) {
        return bookings.stream().map(b -> toDTO(b)).collect(Collectors.toList());
    }

    public Booking toEntity(BookingDTO dto) {
        Booking booking = new Booking();
        booking.setId(dto.getId());
        booking.setStartDate(dto.getStartDate());
        booking.setEndDate(dto.getEndDate());
        // Customer and Property entities should be set separately
        booking.setCustomer(customerRepository.getReferenceById(dto.getCustomerId()));
        booking.setProperty(propertyRepository.getReferenceById(dto.getPropertyId()));
        
        booking.setTotalPrice(dto.getTotalPrice());
        // Owner entity should be set separately
        booking.setOwner(ownerRepository.getReferenceById(dto.getOwnerId()));
        booking.setNumGuests(dto.getNumGuests());
        // Payment and Review entities should be set separately
        booking.setPayment(paymentRepository.getReferenceById(dto.getPaymentId()));
//        booking.setReviews(dto.getReviewIds().stream()
//        		.map(rid -> reviewRepository.getReferenceById(rid)).collect(Collectors.toList()));
        return booking;
    }

}
