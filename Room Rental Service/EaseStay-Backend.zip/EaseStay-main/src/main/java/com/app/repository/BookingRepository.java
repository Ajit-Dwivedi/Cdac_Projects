package com.app.repository;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.app.entity.Booking;
import com.app.entity.Customer;
import com.app.entity.Owner;
import com.app.entity.Property;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    // find all bookings for a specific property
    List<Booking> findAllByProperty(Property property);

    // find all bookings for a specific customer
    List<Booking> findAllByCustomer(Customer customer);

    // find all bookings for a specific owner
    List<Booking> findAllByPropertyOwner(Owner owner);

    // find all bookings that overlap with a specific date range
    @Query("SELECT b FROM Booking b WHERE b.endDate <= ?2 AND b.startDate >= ?1")
    List<Booking> findAllBookingsBetween(LocalDate startDate, LocalDate endDate);
}
