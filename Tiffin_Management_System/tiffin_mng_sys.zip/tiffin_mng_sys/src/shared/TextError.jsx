export const TextError = (props) => {
  return <div className="error-form-msg">{props.children}</div>;
};
