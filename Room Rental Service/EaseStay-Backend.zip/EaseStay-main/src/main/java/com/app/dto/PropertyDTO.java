package com.app.dto;


import java.util.List;

import com.app.entity.Address;
import com.app.entity.Type;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PropertyDTO {
    private Long id;
    private String name;
    private Type type;
    private String features;
    private String description;
    private int capacity;
    private Address address;
    private Double pricePerNight;
    private Long ownerId;
    private List<Long> bookingIds;
    private List<String> imageUrls;
}
