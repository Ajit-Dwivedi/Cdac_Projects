package com.app.service;

import com.app.entity.ImageBlob;

public interface ImageBlobService {

	ImageBlob getImageByImageName(String imageName);
	
	ImageBlob saveImage(ImageBlob imageBlob);
}
