package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.OwnerDTO;
import com.app.dto.PropertyDTO;
import com.app.entity.Owner;
import com.app.entity.Property;
import com.app.mapper.OwnerMapper;
import com.app.mapper.PropertyMapper;
import com.app.service.OwnerService;

@RestController
@RequestMapping("/api/owners")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true", allowedHeaders = "*", methods = {RequestMethod.OPTIONS,
		RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.PATCH, RequestMethod.DELETE, RequestMethod.HEAD, RequestMethod.TRACE
})
public class OwnerController {

    @Autowired
    private OwnerService ownerService;
    
    @Autowired
    private OwnerMapper ownerMapper;
    
    @Autowired
    private PropertyMapper propertyMapper;

   

    @GetMapping("/{id}")
    public ResponseEntity<OwnerDTO> getOwnerById(@PathVariable Long id) {
        Owner owner = ownerService.getOwnerById(id);
        return new ResponseEntity<>(ownerMapper.toDTO(owner), HttpStatus.OK);
        
    
    }

    @PostMapping("")
    public ResponseEntity<OwnerDTO> createOwner(@RequestBody OwnerDTO ownerDTO) {
    	Owner owner = ownerMapper.toOwner(ownerDTO);
        Owner createdOwner = ownerService.createOwner(owner);
        return new ResponseEntity<>(ownerMapper.toDTO(createdOwner), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<OwnerDTO> updateOwner(@PathVariable Long id, @RequestBody OwnerDTO ownerDTO) {
    	Owner owner = ownerMapper.toOwner(ownerDTO);
        Owner updatedOwner = ownerService.updateOwner(id, owner);
        return new ResponseEntity<>(ownerMapper.toDTO(updatedOwner), HttpStatus.OK);
        
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOwner(@PathVariable Long id) {
    	ownerService.deleteOwnerById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}/properties")
    public ResponseEntity<List<PropertyDTO>> getOwnerProperties(@PathVariable Long id) {
        List<Property> properties = ownerService.getProperties(id);
        return ResponseEntity.ok(propertyMapper.toDTOList(properties));
       
    }
}
