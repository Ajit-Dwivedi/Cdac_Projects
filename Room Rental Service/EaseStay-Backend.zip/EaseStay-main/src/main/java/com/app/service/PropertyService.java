package com.app.service;

import java.util.List;

import com.app.dto.Criteria;
import com.app.dto.HotelTypeCountDTO;
import com.app.entity.Property;

public interface PropertyService {

    Property getPropertyById(Long id);

    List<Property> getAllProperties();

    List<Property> getPropertiesByOwnerId(Long ownerId);

    Property saveProperty(Property property);
    
    Property updateProperty(Long id, Property newProperty);

    void deleteProperty(Long id);

    List<Property> getAllPropertiesByCriteria(Criteria criteria);
    
    List<HotelTypeCountDTO> getCountByType();
}
