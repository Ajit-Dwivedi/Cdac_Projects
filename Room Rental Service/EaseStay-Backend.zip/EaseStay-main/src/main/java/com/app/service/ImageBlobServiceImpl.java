package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.ImageBlob;
import com.app.repository.ImageBlobRepository;

@Service
public class ImageBlobServiceImpl implements ImageBlobService {

    @Autowired
    private ImageBlobRepository imageBlobRepository;

	@Override
	public ImageBlob getImageByImageName(String imageName) {
	
		return imageBlobRepository.findByImageName(imageName);
	}

	@Override
	public ImageBlob saveImage(ImageBlob imageBlob) {
	
		
		return imageBlobRepository.save(imageBlob);
	}
}
