package com.app.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.dto.OwnerDTO;
import com.app.entity.Owner;
import com.app.entity.Property;
import com.app.repository.PropertyRepository;

@Component
public class OwnerMapper {
	
	@Autowired
	private PropertyRepository propertyRepository;

    public OwnerDTO toDTO(Owner owner) {
        OwnerDTO ownerDTO = new OwnerDTO();
        ownerDTO.setId(owner.getId());
        ownerDTO.setName(owner.getName());
        ownerDTO.setDateOfBirth(owner.getDateOfBirth());
        ownerDTO.setEmail(owner.getEmail());
        ownerDTO.setPhoneNumber(owner.getPhoneNumber());
        // Only map the owner's ID and name for simplicity
        ownerDTO.setPropertyIds(owner.getProperties().stream()
                .map(Property::getId)
                .collect(Collectors.toList()));
        return ownerDTO;
    }

    public Owner toOwner(OwnerDTO ownerDTO) {
        Owner owner = new Owner();
        owner.setId(ownerDTO.getId());
        owner.setName(ownerDTO.getName());
        owner.setDateOfBirth(ownerDTO.getDateOfBirth());
        owner.setEmail(ownerDTO.getEmail());
        owner.setPhoneNumber(ownerDTO.getPhoneNumber());
        // Only map the owner's ID and name for simplicity
        owner.setProperties(ownerDTO.getPropertyIds().stream()
                .map(propertyId ->  propertyRepository.getReferenceById(propertyId))
                .collect(Collectors.toList()));
        return owner;
    }
    
    public List<OwnerDTO> toDtoList(List<Owner> owners) {
        return owners.stream().map(this::toDTO).collect(Collectors.toList());
    }
}
