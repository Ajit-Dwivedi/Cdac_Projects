const Footer=()=>{
    return(
        <div style={{backgroundColor:"black" ,color:"white"}}>
            
<footer class="page-footer font-small blue pt-4">


  <div class="container-fluid text-center text-md-left">

    
    <div class="row">

      
      <div class="col-md-6 mt-md-0 mt-3">

        
        <h5 class="text-uppercase">E-dabba</h5>
        <p>One cannot think well, love well, sleep well, if one has not dined well.</p>

      </div>
      

      <hr className="clearfix w-100 d-md-none pb-3"/>

      <div class="col-md-3 mb-md-0 mb-3">
      <h5>Contact Us</h5>
      <h6>IET Pune</h6>
      <h6>7620305340</h6>
      <h6>iet1234@gmail.com</h6> 
      
          </div>
      <div class="col-md-3 mb-md-0 mb-3">

        <h5 class="text-uppercase">Social Media</h5>

        <ul class="list-unstyled">
          <li>
            Instagram
          </li>
          <li>
            Linkdin
          </li>
          <li>
            Twitter
          </li>
          <li>
            Facebook
          </li>
        </ul>

      </div>
      
    </div>
  </div>
  
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="/"> MDBootstrap.com</a>
  </div>

</footer>
        </div>
    )
}
export default Footer