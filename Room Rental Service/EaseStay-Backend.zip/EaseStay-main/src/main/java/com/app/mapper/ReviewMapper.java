package com.app.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.dto.ReviewDTO;
import com.app.entity.Review;
import com.app.repository.BookingRepository;
import com.app.repository.CustomerRepository;
import com.app.repository.PropertyRepository;

@Component
public class ReviewMapper {
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private PropertyRepository propertyRepository;
	
    public ReviewDTO toDTO(Review review) {
        ReviewDTO ReviewDTO = new ReviewDTO();
        ReviewDTO.setId(review.getId());
        ReviewDTO.setComment(review.getComment());
        ReviewDTO.setRating(review.getRating());
        ReviewDTO.setCustomerId(review.getCustomer().getId());
        ReviewDTO.setPropertyId(review.getProperty().getId());
        ReviewDTO.setBookingId(review.getBooking().getId());
        return ReviewDTO;
    }

    public List<ReviewDTO> toDTOList(List<Review> reviews) {
        return reviews.stream().map(b -> toDTO(b)).collect(Collectors.toList());
    }
    
    public Review toEntity(ReviewDTO dto) {
        Review review = new Review();
        review.setId(dto.getId());
        review.setComment(dto.getComment());
        review.setRating(dto.getRating());
        // setCustomer, setProperty, and setBooking should be implemented separately
        review.setCustomer(customerRepository.getReferenceById(dto.getCustomerId()));
        review.setProperty(propertyRepository.getReferenceById(dto.getPropertyId()));
        review.setBooking(bookingRepository.getReferenceById(dto.getBookingId()));
        return review;
    }
    
    
}
