package com.app.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.Criteria;
import com.app.dto.PropertyDTO;
import com.app.dto.ReviewDTO;
import com.app.entity.Property;
import com.app.mapper.PropertyMapper;
import com.app.mapper.ReviewMapper;
import com.app.service.PropertyService;
import com.app.service.ReviewService;

@RestController
@RequestMapping("/api/properties")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true", allowedHeaders = "*", methods = {RequestMethod.OPTIONS,
		RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.PATCH, RequestMethod.DELETE, RequestMethod.HEAD, RequestMethod.TRACE
})
public class PropertyController {
    
    @Autowired
    private PropertyMapper propertyMapper;
    
    @Autowired
    private ReviewMapper reviewMapper;
    
    @Autowired
    private PropertyService propertyService;
    
    @Autowired
    private ReviewService reviewService;
    
    @GetMapping
    public ResponseEntity<List<PropertyDTO>> getAllProperties() {
        List<Property> properties = propertyService.getAllProperties();
        List<PropertyDTO> propertyDTOs = properties.stream()
                .map(property -> propertyMapper.toDTO(property))
                .collect(Collectors.toList());
        return new ResponseEntity<>(propertyDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<PropertyDTO> getPropertyById(@PathVariable("id") Long id) {
        Property property = propertyService.getPropertyById(id);
        PropertyDTO propertyDTO = propertyMapper.toDTO(property);
        return new ResponseEntity<>(propertyDTO, HttpStatus.OK);
    }
    
    @PostMapping
    public ResponseEntity<PropertyDTO> createProperty(@RequestBody PropertyDTO propertyDTO) {
        Property property = propertyMapper.toEntity(propertyDTO);
        property = propertyService.saveProperty(property);
        PropertyDTO createdPropertyDTO = propertyMapper.toDTO(property);
        return new ResponseEntity<>(createdPropertyDTO, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<PropertyDTO> updateProperty(@PathVariable("id") Long id, @RequestBody PropertyDTO propertyDTO) {
        Property property = propertyMapper.toEntity(propertyDTO);
        property = propertyService.updateProperty(id, property);
        PropertyDTO updatedPropertyDTO = propertyMapper.toDTO(property);
        return new ResponseEntity<>(updatedPropertyDTO, HttpStatus.OK);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProperty(@PathVariable("id") Long id) {
        
        propertyService.deleteProperty(id);
        return ResponseEntity.noContent().build();
    }
    
    @PostMapping("/filter")
    public ResponseEntity<List<PropertyDTO>> getAllBookingPropertiesFrom
                                 (@RequestBody Criteria criteria)
    {	
        List<Property> properties  = propertyService
        		                            .getAllPropertiesByCriteria(criteria);
        List<PropertyDTO> propertyDTOs = properties.stream()
                .map(property -> propertyMapper.toDTO(property))
                .collect(Collectors.toList());
        return new ResponseEntity<>(propertyDTOs, HttpStatus.OK);
    }
    
    @GetMapping("/type/count")
    public ResponseEntity<?> getHotelsCountByType(){
    	
    	return ResponseEntity.ok(propertyService.getCountByType());
    	
    }
    
    @GetMapping("/reviews/{id}")
    public ResponseEntity<List<ReviewDTO>> getReviewsByPropertyId(@PathVariable("id") Long id){
    	
    	List<ReviewDTO> reviewDTOs = reviewMapper.toDTOList(reviewService.findReviewsByProperyId(id));
        return new ResponseEntity<>(reviewDTOs, HttpStatus.OK);
    	
    }
}
